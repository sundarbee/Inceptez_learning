from PythonProg.PythonForDevelopers import Class_Funct_Module
#from PythonProg.PythonForDevelopers import FunctionsExample
obj2=Class_Funct_Module.calc()
print(obj2.add(100,200))
print(obj2.sub(200,100))


