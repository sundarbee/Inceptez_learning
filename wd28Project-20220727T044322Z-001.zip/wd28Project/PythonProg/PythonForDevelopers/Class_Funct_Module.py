class calc:
    def add(self,a,b):
        return a+b
    def sub(self,a,b):
        return a-b
'''obj1=calc()
print(obj1.sub(100,10))'''