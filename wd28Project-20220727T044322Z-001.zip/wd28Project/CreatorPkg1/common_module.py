def summation(x,y=0):
    z=x+y
    print("summation of x and y is {}".format(z))
    return z

def taxation(x,y=0):
    z=x-y
    print("tax reduced salary is {}".format(z))
    return z


