x=int(input())
y=int(input())
z=x+y
print("summation of x and y is {}".format(z))