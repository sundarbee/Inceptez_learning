from CreatorPkg1 import common_module
x=common_module.summation(y=10,x=20)
y=common_module.summation(10,200)
print(x)
print(y)
x=common_module.taxation(y=2000,x=10000)
y=common_module.taxation(10000,10000)
print(x)
print(y)
