from MainRoad.Street import Showroom
#dhuren's computer harddisk Showroom.CarSales
objsalerep1=Showroom.CarSales()
costofthecarcustomer1=objsalerep1.swift('red')
costofthecarcustomer2=objsalerep1.swift('blue')
print(costofthecarcustomer1)
print(costofthecarcustomer2)

objserviceengg1=Showroom.CarService()
servicecostofthecarcustomer1=objserviceengg1.swift('water')
servicecostofthecarcustomer2=objserviceengg1.alto('complete')
print(servicecostofthecarcustomer1)
print(servicecostofthecarcustomer2)