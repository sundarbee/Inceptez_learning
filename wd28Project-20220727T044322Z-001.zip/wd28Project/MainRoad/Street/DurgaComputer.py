from MainRoad.Street import Showroom
#dhuren's computer harddisk Showroom.CarSales
objsalerep1=Showroom.CarSales()
costofthecarcustomer1=objsalerep1.swift('white')
costofthecarcustomer2=objsalerep1.swift('orange')
print(costofthecarcustomer1)
print(costofthecarcustomer2)

objserviceengg1=Showroom.CarService()
servicecostofthecarcustomer1=objserviceengg1.swift('water')
print(servicecostofthecarcustomer1)
